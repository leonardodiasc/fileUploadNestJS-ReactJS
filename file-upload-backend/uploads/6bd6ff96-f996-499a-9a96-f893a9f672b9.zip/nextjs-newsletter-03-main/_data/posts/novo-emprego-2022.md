---
date: 2022-08-29
title: "Meu Novo Emprego na Empresa X"
url: https://www.linkedin.com/in/omariosouto
excerpt: "É uma nova fase na minha vida..."
tags: 
  - emprego-novo
  - empresa-x
---

# Como tudo começou!

Estava eu sentado, numa sexta a noite, fazia frio...
