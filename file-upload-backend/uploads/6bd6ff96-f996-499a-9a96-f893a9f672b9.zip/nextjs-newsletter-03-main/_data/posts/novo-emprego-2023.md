---
date: 2022-08-29
image: https://source.unsplash.com/random/800x600
title: "Meu Novo Emprego na Empresa Y"
url: https://www.linkedin.com/in/omariosouto
excerpt: "É uma nova fase na minha vida..."
tags: 
  - emprego-novo
  - empresa-y
---

# Como tudo começou!

Estava eu sentado, numa sexta a noite, fazia frio...
